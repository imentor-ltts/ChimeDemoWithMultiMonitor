﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChimeAppLauncherWinService
{
    public class LaunchSettings
    {
        public string ExePath { get; set; } = string.Empty;
        public string LogFilePath { get; set; } = string.Empty;
        public string LogFolderPath { get; set; } = string.Empty;
    }
}
