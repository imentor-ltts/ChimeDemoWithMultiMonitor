using ChimeAppLauncherWinService;
using Microsoft.Extensions.Logging.EventLog;
using SampleWinService;

string meetingId = string.Empty;
string[] cmdArgs = Environment.GetCommandLineArgs();
if (cmdArgs.Length > 0)
{ 
    meetingId = cmdArgs[0];
}
else
{
    meetingId = "801445";
}

IHost host = Host.CreateDefaultBuilder(args)
    .ConfigureLogging(options =>
    {
        if (OperatingSystem.IsWindows())
        {
            options.AddFilter<EventLogLoggerProvider>(level => level >= LogLevel.Information);
        }
    })
    .ConfigureAppConfiguration((hostContext, configBuilder) =>
    {
        // Add configuration from appsettings.json
        configBuilder.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
    })
    .ConfigureServices((hostContext, services) =>
    {
        services.Configure<CommandLineArgs>(hostContext.Configuration.GetSection("CommandLineArgs"));
        services.AddHostedService<Worker>();
        if (OperatingSystem.IsWindows())
        {
            services.Configure<EventLogSettings>(config =>
            {
                if (OperatingSystem.IsWindows())
                {
                    config.LogName = "ChimeAppLauncherWinService";
                    config.SourceName = "Chime App Launcher Service Code";
                }
            });
        }
    })
    .UseWindowsService()
    .Build();

host.Run();

